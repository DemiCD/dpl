---------- DPL BINARY FILE RELEASE ----------
ZIP BUILD DATE: 06/03/21
AUTHOR: Alan Kubiak

include:

VM: The DPL Virtual Machine can execute DPL binary files (.dplc). Note: Only files named "program.dplc", just add it in the VM directory, and launch the VM.

COMPILER: Allows compile DPL code files (.dpl) into DPL binary files (.dplc).

functions:

output: (output["Hello, World!"]:) - Print an argument.

input: (x = input[]:) - Input a numerical value.

pi: (x = pi[]:) - Pi.

random: (x = rand[value]:) - Input a random numerical value.

sleep: (sleep[milliseconds]:) - Sleep system for an definite time.

colorC: (colorC[color]:) - Change terminal color.

pause: (pause[]:) - Pause system.